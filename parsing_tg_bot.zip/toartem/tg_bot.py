import logging
import re
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes, CallbackContext
import requests

# Настройка логов
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class TelegramBot:
    def get_my_username_from_db(self, telegram_chat_id: int) -> str:

        try:
            
            response = requests.get(
                f"https://www.dwbh.store/tg_user?chat_id={telegram_chat_id}",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                user_data = response.json()
                return user_data.get('username', '')
                
            logger.error(f"Ошибка запроса: {response.status_code}")
            return ""
            
        except Exception as e:
            logger.error(f"Ошибка при получении username: {str(e)}")
            return ""



    def __init__(self, api_client):
        self.api = api_client

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /start"""
        await update.message.reply_text("Бот запущен. Используйте /register для регистрации")

    async def register(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды регистрации"""
        user = update.effective_user
        chat_id = update.effective_chat.id
        
        if not user.username:
            await update.message.reply_text("❌ Для регистрации нужен username в Telegram")
            return
            
        await update.message.reply_text(f"🔹 Ваш Telegram: @{user.username}")
        
        
        user_info = self.api.get_user_info(user.username)
        if not user_info:
            await update.message.reply_text("❌ Ошибка получения данных")
            return
            
    
        if self.api.register_user_chat(user_info['id'], chat_id):
            await update.message.reply_text("✅ Регистрация завершена!")
        else:
            await update.message.reply_text("❌ Ошибка регистрации")

    def run(self, token: str):
        """Запуск бота"""
        app = Application.builder().token(token).build()
        app.add_handler(CommandHandler("start", self.start))
        app.add_handler(CommandHandler("register", self.register))
        
        logger.info("Бот запущен")
        app.run_polling()

class ApiClient:
    def __init__(self):
        self.api_token = None
        self.headers = {"Content-Type": "application/json"}
        self.chat_id_pattern = re.compile(r'^\d{8,12}$')
        self.authenticate()

    async def my_username(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Команда /me для показа своего username"""
        chat_id = update.effective_chat.id
        username = self.api.get_my_username_from_db(chat_id)
        
        if username:
            await update.message.reply_text(f"Ваш username в системе: @{username}")
        else:
            await update.message.reply_text("❌ Ваш username не найден в базе")

    

    def authenticate(self):
        """Аутентификация на API"""
        try:
            response = requests.post(
                "https://www.dwbh.store/api/token/",
                json={"username": "123", "password": "123"},
                timeout=10
            )
            
            if response.status_code == 200:
                self.api_token = response.json().get('access')
                self.headers["Authorization"] = f"Bearer {self.api_token}"
                return True
        except Exception as e:
            logger.error(f"Ошибка аутентификации: {str(e)}")
        return False

    def get_user_info(self, username):
        """Получение информации о пользователе"""
        try:
            response = requests.get(
                f"https://www.dwbh.store/tg_user?tg=@{username}",
                headers=self.headers,
                timeout=10
            )
            return response.json() if response.status_code == 200 else None
        except Exception as e:
            logger.error(f"Ошибка запроса пользователя: {str(e)}")
            return None

    def register_user_chat(self, user_id, chat_id):
        """Регистрация/обновление chat_id пользователя"""
        if not self.chat_id_pattern.match(str(chat_id)):
            logger.error(f"Невалидный chat_id: {chat_id}")
            return False
            
        try:
            response = requests.put(
                f"https://www.dwbh.store/tg_user/{user_id}",
                headers=self.headers,
                json={"telegram_chat_id": chat_id},
                timeout=10
            )
            return response.status_code in [200, 201]
        except Exception as e:
            logger.error(f"Ошибка регистрации чата: {str(e)}")
            return False

    def get_valid_subscribers(self):
        """Получение валидных подписчиков"""
        try:
            response = requests.get(
                "https://www.dwbh.store/subs_user",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                return [
                    sub['chat_id'] for sub in response.json()
                    if 'chat_id' in sub and self.chat_id_pattern.match(str(sub['chat_id']))
                ]
        except Exception as e:
            logger.error(f"Ошибка получения подписчиков: {str(e)}")
        
        return []
    
    

if __name__ == '__main__':
    
    api_client = ApiClient()
    
    bot = TelegramBot(api_client)
    bot.run("7629828103:AAGsbEXpYTSGN9EmyT6_HJSXMow5NReG0zQ")