from bs4 import BeautifulSoup
from urllib.parse import urljoin
import re

class ScienceRFNewsParser:
    @staticmethod
    def parse_news_html(html_content, base_url=''):

        return ScienceRFNewsParser.parse_news_page(html_content, base_url)

    @staticmethod
    def parse_news_page(html_content, base_url=''):
        
        result = {
            'date': '',
            'title': '',
            'main_image': {'url': '', 'description': ''},
            'content': '',
            'tags': [],
            'success': False,
            'error': None
        }
        
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            
            result['date'] = ScienceRFNewsParser._clean_text(ScienceRFNewsParser._parse_date(soup))
            result['title'] = ScienceRFNewsParser._clean_text(ScienceRFNewsParser._parse_title(soup))
            
            
            content_block = soup.find('div', class_='u-news-detail-page__text-content')
            if content_block:
                result['content'] = ScienceRFNewsParser._parse_content(content_block, base_url)
                result['main_image'] = ScienceRFNewsParser._parse_main_image(content_block, base_url)
            
            result['tags'] = ScienceRFNewsParser._parse_tags(soup)
            result['success'] = True
            
        except Exception as e:
            result['error'] = str(e)
            result['success'] = False
        
        return result

    @staticmethod
    def _clean_text(text):
        """Удаляет неразрывные пробелы и лишние whitespace"""
        if not text:
            return text
        return re.sub(r'\s+', ' ', text.replace('\xa0', ' ')).strip()

    @staticmethod
    def _parse_date(soup):
        date_block = soup.find('time', class_='u-news-detail__date')
        return date_block.get_text(strip=True) if date_block else ''

    @staticmethod
    def _parse_title(soup):
        title_block = soup.find('h1', class_='u-inner-header__title')
        return title_block.get_text(strip=True) if title_block else ''

    @staticmethod
    def _parse_main_image(news_block, base_url):
        
        img = news_block.find(['img', 'img-wyz'])
        if img:
            src = img.get('src')
            if src:
                if not src.startswith(('http://', 'https://')):
                    src = urljoin(base_url, src)
                
                return {
                    'url': src,
                    'description': ScienceRFNewsParser._clean_text(img.get('alt', ''))
                }
        return {'url': '', 'description': ''}

    @staticmethod
    def _parse_tags(soup):
        return []  

    @staticmethod
    def _parse_content(content_block, base_url):
        content = BeautifulSoup(str(content_block), 'html.parser')
        
        for img_wyz in content.find_all('img-wyz'):
            src = img_wyz.get('src')
            if src:
                new_img = content.new_tag('img')
                if not src.startswith(('http://', 'https://')):
                    src = urljoin(base_url, src)
                new_img['src'] = src
                img_wyz.replace_with(new_img)
        
        
        for img in content.find_all('img'):
            if img.get('src'):
                img_src = img['src']
                if not img_src.startswith(('http://', 'https://')):
                    img['src'] = urljoin(base_url, img_src)
                
                for attr in list(img.attrs.keys()):
                    if attr != 'src':
                        del img[attr]
        
        
        for unwanted in content.find_all(['script', 'style']):
            unwanted.decompose()
        
        
        content_html = str(content)
        content_html = content_html.replace('\xa0', ' ')
        
        return content_html



if __name__ == "__main__":
    from downloader import HTMLDownloader  

    url = "https://наука.рф/news/samye-interesnye-otkrytiya-uchenykh-za-pervuyu-nedelyu-aprelya/"
    downloader_result = HTMLDownloader.download_page(url)

    if downloader_result['success']:
        parsed_data = ScienceRFNewsParser.parse_news_html(
            downloader_result['html'],
            downloader_result['base_url']
        )
        print(parsed_data)
    else:
        print(f"Ошибка при загрузке страницы: {downloader_result['error']}")