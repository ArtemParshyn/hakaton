import time
from datetime import datetime
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from downloader import HTMLDownloader
from toartem.RNF import RSCF

class GlobalNewsParser:
    def __init__(self, api_username, api_password, base_url):
        """Инициализация парсера"""
        self.api_username = api_username
        self.api_password = api_password
        self.base_url = base_url.rstrip('/')
        self.api_token = None
        self.news_list_url = f"{self.base_url}/news/"
        
        print(f"[Parser] Инициализирован для {self.base_url}")
        print(f"[Auth] Используются учетные данные: {self.api_username}")

    def authenticate(self):
        """Аутентификация на API"""
        print("\n[Auth] Попытка аутентификации...")
        try:
            response = requests.post(
                "https://www.dwbh.store/api/token/",
                json={"username": self.api_username, "password": self.api_password},
                timeout=10
            )
            
            if response.status_code == 200:
                self.api_token = response.json().get('access')
                print("[Auth] Успешная аутентификация")
                return True
                
            print(f"[Auth] Ошибка: {response.status_code} - {response.text}")
            return False
            
        except Exception as e:
            print(f"[Auth] Ошибка соединения: {str(e)}")
            return False

    def get_existing_news_links(self):
        """Получает список существующих новостей из API"""
        if not self.api_token:
            raise Exception("Требуется аутентификация")
            
        print("\n[API] Запрос существующих новостей...")
        try:
            response = requests.get(
                "https://www.dwbh.store/news/",
                headers={"Authorization": f"Bearer {self.api_token}"},
                timeout=10
            )
            
            if response.status_code == 200:
                existing_news = response.json()
                links = {news['sources'] for news in existing_news if 'sources' in news}
                print(f"[API] Получено {len(links)} существующих новостей")
                return links
                
            print(f"[API] Ошибка: {response.status_code} - {response.text}")
            return set()
            
        except Exception as e:
            print(f"[API] Ошибка соединения: {str(e)}")
            return set()

    def parse_news_list(self):
        """Парсит список новостей с сайта"""
        print(f"\n[Parser] Загрузка {self.news_list_url}")
        result = HTMLDownloader.download_page(self.news_list_url)
        
        if not result['success']:
            raise Exception(f"Ошибка загрузки: {result['error']}")
            
        print("[Parser] Парсинг новостей...")
        soup = BeautifulSoup(result['html'], 'html.parser')
        news_items = soup.find_all('div', class_='news-item')
        
        news_list = []
        for item in news_items:
            title_element = item.find('a', class_='news-title')
            if title_element and 'href' in title_element.attrs:
                news_list.append({
                    'title': title_element.get_text(strip=True),
                    'link': urljoin(self.base_url, title_element['href'])
                })
        
        print(f"[Parser] Найдено {len(news_list)} новостей")
        return news_list

    def ensure_tags_exist(self, tags):
        """Убеждается, что теги существуют в системе (создает при необходимости)"""
        if not tags:
            print("[Tags] Нет тегов для обработки")
            return True
            
        print(f"[Tags] Обработка тегов: {tags}")
        
        for tag in tags:
            try:
                
                response = requests.post(
                    "https://www.dwbh.store/tags/",
                    json={"name": tag},
                    headers={
                        "Authorization": f"Bearer {self.api_token}",
                        "Content-Type": "application/json"
                    },
                    timeout=10
                )
                
                if response.status_code not in (201, 400):
                    print(f"[Tags] Ошибка обработки тега '{tag}': {response.status_code} - {response.text}")
                    return False
                    
            except Exception as e:
                print(f"[Tags] Ошибка создания тега '{tag}': {str(e)}")
                return False
                
        return True

    def process_single_news(self, news_info):
        """Обрабатывает одну новость"""
        print(f"\n[News] Обработка новости: {news_info['title']}")
        
        
        print("[News] Загрузка страницы новости...")
        result = HTMLDownloader.download_page(news_info['link'])
        if not result['success']:
            print(f"[News] Ошибка загрузки: {result['error']}")
            return False
            
        
        parsed_data = RSCF.parse_news_html(result['html'], result['base_url'])
        if not parsed_data['success']:
            print(f"[News] Ошибка парсинга: {parsed_data['error']}")
            return False
        
        
        if not self.ensure_tags_exist(parsed_data['tags']):
            print("[News] Пропуск новости из-за ошибки обработки тегов")
            return False
        
        
        news_data = {
            "title": news_info['title'],
            "content": parsed_data['content'],
            "created_at": datetime.now().isoformat(),
            "status": "PUBLISHED",
            "author": 1,
            "sources": news_info['link'],
            "cover": parsed_data['main_image']['url'] if parsed_data['main_image'] else None,
            "tags": parsed_data['tags'] 
        }
        
        
        print("[News] Отправка данных новости...")
        headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.post(
                "https://www.dwbh.store/news/",
                json=news_data,
                headers=headers,
                timeout=15
            )
            
            if response.status_code == 201:
                print("[News] Успешно добавлена!")
                return True
                
            print(f"[News] Ошибка: {response.status_code} - {response.text}")
            return False
            
        except Exception as e:
            print(f"[News] Ошибка: {str(e)}")
            return False

    def process_new_news(self):
        """Основной метод обработки новых новостей"""
        if not self.authenticate():
            raise Exception("Ошибка аутентификации")
            
        existing_links = self.get_existing_news_links()
        news_list = self.parse_news_list()
        
        new_news = [news for news in news_list if news['link'] not in existing_links]
        print(f"\n[Main] Найдено {len(new_news)} новых новостей")
        
        success_count = 0
        for news in new_news:
            if self.process_single_news(news):
                success_count += 1
                
        print(f"\n[Main] Итог: успешно обработано {success_count}/{len(new_news)}")

def main(site_url, check_interval_hours=1):
    """Главная функция"""
    print(f"\n{'='*50}")
    print(f"Парсер запущен для: {site_url}")
    print(f"Интервал проверки: {check_interval_hours} ч.")
    print(f"Время запуска: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*50)
    
    parser = GlobalNewsParser(
        api_username="123",
        api_password="123",
        base_url=site_url
    )
    
    while True:
        try:
            print(f"\n{'-'*50}")
            print(f"Проверка: {datetime.now().strftime('%H:%M:%S')}")
            
            parser.process_new_news()
            
            print(f"\nСледующая проверка через {check_interval_hours} ч.")
            print("-"*50)
            time.sleep(check_interval_hours * 3600)
            
        except KeyboardInterrupt:
            print("\nОстановлено пользователем")
            break
        except Exception as e:
            print(f"\nОшибка: {str(e)}")
            print("Повтор через 5 минут...")
            time.sleep(300)

if __name__ == "__main__":
    main(
        site_url="https://rscf.ru",
        check_interval_hours=5
    )